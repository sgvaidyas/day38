﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCatalog
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
                // Create and initialize a CheckBox.   
                CheckBox checkBox1 = new CheckBox();

                // Make the check box control appear as a toggle button.
                checkBox1.Appearance = Appearance.Button;

                // Turn off the update of the display on the click of the control.
                checkBox1.AutoCheck = false;

                // Add the check box control to the form.
                Controls.Add(checkBox1);
            

        }
    }
}
