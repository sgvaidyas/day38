﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCatalog
{
    public partial class Form13 : Form
    {
        private PrintDocument printDocument1;

        public Form13()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PrintPreviewDialog PrintPreviewDialog1 = new PrintPreviewDialog();
            PrintPreviewDialog1.Document = printDocument1;
            PrintPreviewDialog1.ShowDialog();

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("This is printing stmnt", new Font("Arial", 14), Brushes.Black, new Point(50, 50));

        }
    }
}
