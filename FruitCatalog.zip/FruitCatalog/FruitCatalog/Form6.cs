﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCatalog
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
            
        }
        void CreateContextMenu()
        {
            ContextMenuStrip mymenu = new ContextMenuStrip();
            ToolStripMenuItem menu = new ToolStripMenuItem("Exit");

            menu.Click += new EventHandler(menu_Click);
            menu.Name = "Exit";
            mymenu.Items.Add(menu);

            this.ContextMenuStrip = mymenu;
        }
        void menu_Click(object sender, EventArgs e)
        {
            ToolStripItem menu = (ToolStripItem)sender;
            if (menu.Name == "Exit")
            {
                Application.Exit();
            }
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            DateTime dateTime = new DateTime();
            MessageBox.Show(dateTime.ToShortDateString().ToString());

            //........................yyyy-mm-dd
            DateTime d1 = new DateTime(2021,2,11);
            MessageBox.Show(d1.ToShortDateString().ToString());


        }
    }
}
