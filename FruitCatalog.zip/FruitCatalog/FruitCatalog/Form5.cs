﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace FruitCatalog
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            ComboBox combo1 = new ComboBox();
            combo1.Location = new Point(20, 100);
            combo1.Size = new Size(300, 40);
            combo1.Items.Add("Hi");
            combo1.Items.Add("Hello");
            combo1.Items.Add("Combo");

            this.Controls.Add(combo1);
        }
    }
}
