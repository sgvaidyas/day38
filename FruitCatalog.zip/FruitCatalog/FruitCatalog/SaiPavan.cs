﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCatalog
{
    public partial class SaiPavan : Form
    {
        public SaiPavan()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult fontResult = fontDialog1.ShowDialog();
            if (fontResult == DialogResult.OK)
            {
                button1.Font = fontDialog1.Font;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            DialogResult fontResult = fontDialog1.ShowDialog();
            if (fontResult == DialogResult.OK)
            {
                label1.Font = fontDialog1.Font;
            }
        }

        private void SaiPavan_Load(object sender, EventArgs e)
        {
            GroupBox box = new GroupBox();
            box.Location = new Point(179, 145);
            box.Size = new Size(329, 94);
            box.Text = "Select Gender";
            box.Name = "MyGroupbox";

            this.Controls.Add(box);

            CheckBox b1 = new CheckBox();
            b1.Location = new Point(40, 42);
            b1.Size = new Size(49, 20);
            b1.Text = "Male";

            this.Controls.Add(b1);

            CheckBox b2 = new CheckBox();
            b1.Location = new Point(183, 39);
            b1.Size = new Size(69, 20);
            b1.Text = "Female";

            this.Controls.Add(b2);

        }

        
    }
}
