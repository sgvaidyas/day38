﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCatalog
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // Create and initialize a CheckBox.   
            CheckBox checkBox1 = new CheckBox();

            // Make the check box control appear as a toggle button.

            // Turn off the update of the display on the click of the control.
            checkBox1.AutoCheck = true;
            checkBox1.Location=new Point(125, 40);
            checkBox1.Text = "Male";

            // Add the check box control to the form.
            Controls.Add(checkBox1);

        }
    }
}
