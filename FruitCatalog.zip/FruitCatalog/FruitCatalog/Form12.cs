﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCatalog
{
    public partial class Form12 : Form
    {
        FileSystemWatcher watcher;
        public Form12()
        {
            InitializeComponent();
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            watch();
        }

        void watch()
        {
            try
            {
                // Create a new FileSystemWatcher and set its properties.
                watcher = new FileSystemWatcher();

                watcher.Path = @"D:/images/";

                //watch any type of files      
                watcher.Filter = ".";

                /* Watch for changes in LastAccess and LastWrite times, and
                      the renaming of files or directories. */
                watcher.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite
                                       | NotifyFilters.FileName | NotifyFilters.DirectoryName;


                // Add event handler.
                watcher.Changed += new FileSystemEventHandler(OnChanged);
                // Begin watching.      
                watcher.EnableRaisingEvents = true;
            }
            catch (Exception)
            {
                MessageBox.Show("Not found");
            }
        }
        // Define the event handler.
        private void OnChanged(object source, FileSystemEventArgs e)
        {
            //Copies file to another directory or another action.
            MessageBox.Show("File : " + e.FullPath + " " + e.ChangeType);
        }
    }
}
