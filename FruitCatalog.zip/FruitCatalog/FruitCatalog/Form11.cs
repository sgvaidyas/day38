﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCatalog
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            FlowLayoutPanel fl = new FlowLayoutPanel();
            fl.Location = new Point(180, 125);
            fl.Size = new Size(250, 60);
            fl.Name = "Myflowpanel";
            fl.Font = new Font("Calibri", 12);
            fl.FlowDirection = FlowDirection.RightToLeft;
            fl.BorderStyle = BorderStyle.Fixed3D;
            fl.ForeColor = Color.BlueViolet;
            fl.Visible = true;

            this.Controls.Add(fl);

            RadioButton f1 = new RadioButton();
            f1.Location = new Point(94, 3);
            f1.Size = new Size(95, 20);
            f1.Text = "R1";
            fl.Controls.Add(f1);

            RadioButton f2 = new RadioButton();
            f2.Location = new Point(94, 3);
            f2.Size = new Size(95, 20);
            f2.Text = "R2";

            fl.Controls.Add(f2);

            RadioButton f3 = new RadioButton();
            f3.Location = new Point(94, 3);
            f3.Size = new Size(95, 20);
            f3.Text = "R2";

            fl.Controls.Add(f3);

        }
    }
}
