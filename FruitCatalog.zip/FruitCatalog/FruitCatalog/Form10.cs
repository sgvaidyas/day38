﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCatalog
{
    public partial class Form10 : Form
    {
        private Label label1;
        private TextBox nameTextBox1, txt2;
        private ErrorProvider nameErrorProvider;

        public Form10()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            this.label1 = new Label();

            this.nameTextBox1 = new TextBox();
            this.txt2 = new TextBox();

            this.txt2.Location = new Point(56, 120);
            this.txt2.Size = new Size(40, 23);
            this.label1.Text = "Name";

            this.nameTextBox1.Location = new Point(112, 32);
            this.nameTextBox1.Size = new Size(120, 20);
            //this.nameTextBox1.TabIndex = 0;
            this.nameTextBox1.Validated += new System.EventHandler(this.nameTextBox1_Validated);

            this.ClientSize = new Size(464, 250);
            this.Controls.AddRange(new Control[] { this.label1, this.nameTextBox1, txt2 });

            this.Text = "Error Provider Example";

            nameErrorProvider = new ErrorProvider();
            nameErrorProvider.SetIconAlignment(this.nameTextBox1, ErrorIconAlignment.MiddleRight);
            nameErrorProvider.SetIconPadding(this.nameTextBox1, 2);
            nameErrorProvider.BlinkRate = 1000;
            nameErrorProvider.BlinkStyle = ErrorBlinkStyle.AlwaysBlink;

        }

        private void nameTextBox1_Validated(object sender,System.EventArgs e)
        {
            if(IsNameValid())
            {
                nameErrorProvider.SetError(this.nameTextBox1, string.Empty);
            }
            else
            {
                nameErrorProvider.SetError(this.nameTextBox1, "Name is required");

            }

        }

        private bool IsNameValid()
        {
            return (nameTextBox1.Text.Length > 0);
        }

    }
}
