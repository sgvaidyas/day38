﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCatalog
{
    public partial class Form15 : Form
    {
        bool flag = true;
        public Form15()
        {
            InitializeComponent();
        }

        private void Form15_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Text = "CPU Usage: " + performanceCounter1.NextValue();
        }
        /*
        private void start_Click(object sender, EventArgs e)
        {
            while(flag)
            {
                label1.Text = "CPU Usage: " + performanceCounter1.NextValue();
            }
            
        }

        private void stop_Click(object sender, EventArgs e)
        {
            flag = false;
        }
        */
    }
}
