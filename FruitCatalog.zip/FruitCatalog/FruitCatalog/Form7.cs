﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCatalog
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
            CreateContextMenu();
        }
        

        void CreateContextMenu()
        {
            ContextMenuStrip mymenu = new ContextMenuStrip();
            ToolStripMenuItem menu = new ToolStripMenuItem("Exit");

            menu.Click += new EventHandler(menu_Click);
            menu.Name = "Exit";
            mymenu.Items.Add(menu);
            menu.Image = Image.FromFile(@"C:\Users\acer\Pictures\IMG-20201026-WA0003.jpg");
            menu.ShortcutKeys = Keys.Alt | Keys.X;
            menu.DisplayStyle = ToolStripItemDisplayStyle.ImageAndText;
            this.ContextMenuStrip = mymenu;
            //mymenu.Show();
            //this.Controls.Add(mymenu);

        }

        void menu_Click(object sender, EventArgs e)
        {
            ToolStripItem menu = (ToolStripItem)sender;
            if (menu.Name == "Exit")
            {
                //MessageBox.Show("Application Exiting");
                Application.Exit();
            }
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            //this.ContextMenuStrip = mymenu;
        }
    }
}
