﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FruitCatalog
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            DomainUpDown d = new DomainUpDown();
            d.Size = new System.Drawing.Size(100, 100);
            d.Location = new System.Drawing.Point(10, 50);
            d.Items.Add("hello");
            d.Items.Add("world");
            d.SelectedIndex = 0;
            Controls.Add(d);
        }
    }
}
